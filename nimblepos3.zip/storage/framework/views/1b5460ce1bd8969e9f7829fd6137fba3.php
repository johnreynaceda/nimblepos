<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
    <style>
        [x-cloak] {
            display: none !important;
        }
    </style>
    <?php echo \Filament\Support\Facades\FilamentAsset::renderStyles() ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>

<body class="font-sans antialiased h-screen bg-gradient-to-tl from-gray-300 to-gray-100">
    <img src="<?php echo e(asset('images/logo.jpg')); ?>" class="absolute bottom-0 object-cover w-full opacity-5 rounded-3xl"
        alt="">
    <section class="relative">
        <div class="px-8 py-40 mx-auto md:px-12 lg:px-32 max-w-7xl">
            <div class="grid items-center gap-12 lg:grid-cols-2 lg:gap-24">
                <div class="">
                    <img src="<?php echo e(asset('images/logo.jpg')); ?>" class="h-36 rounded-2xl flex-shrink-0" alt="">
                    <h1 class="text-4xl mt-5 font-poppins font-black tracking-tighter text-gray-700 lg:text-5xl">
                        Nimble POS
                    </h1>
                    <h1 class="text-sm">Since 2024</h1>

                </div>
                <div class="p-2 border bg-gray-600 shadow-xl rounded-3xl">
                    <div class="p-10 bg-white border shadow-lg rounded-2xl">
                        
                        <div class="mb-5">
                            <h1 class="text-lg font-semibold"> Welcome.</h1>
                            <p class="text-sm">Please enter your credentials.</p>
                        </div>
                        <?php echo e($slot); ?>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php echo \Filament\Support\Facades\FilamentAsset::renderScripts() ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</body>

</html>
<?php /**PATH C:\Users\johnr\Herd\nimblepos\resources\views/layouts/guest.blade.php ENDPATH**/ ?>