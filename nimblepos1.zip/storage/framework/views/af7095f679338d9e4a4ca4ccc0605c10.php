<div x-data="{ modalIsOpen: <?php if ((object) ('receipt') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('receipt'->value()); ?>')<?php echo e('receipt'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('receipt'); ?>')<?php endif; ?> }">

    <div class="mx-10 relative">
        <div class="mr-[30rem]   ">
            <div class="px-5">
                <h1 class="font-bold text-xl font-poppins text-gray-700">POINT OF SALES</h1>
                <div class="mt-10">
                    <h1 class="text-sm text-gray-500">Menu Items(<?php echo e($products->count()); ?>)</h1>
                    <div class="mt-4 flex space-x-3">

                        <button wire:click="$set('selected_category', '')"
                            class="<?php echo e($selected_category == null ? 'bg-gray-500 text-white' : ''); ?> border hover:text-white hover:bg-gray-500 hover:scale-95 border-gray-400 rounded-full px-2 flex space-x-1 text-gray-800 py-1 items-center">
                            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24"
                                fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round"
                                class="icon icon-tabler icons-tabler-outline icon-tabler-package">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                <path d="M12 3l8 4.5l0 9l-8 4.5l-8 -4.5l0 -9l8 -4.5" />
                                <path d="M12 12l8 -4.5" />
                                <path d="M12 12l0 9" />
                                <path d="M12 12l-8 -4.5" />
                                <path d="M16 5.25l-8 4.5" />
                            </svg>
                            <span class="text-sm font-medium">All Menu</span>
                        </button>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button wire:click="$set('selected_category', <?php echo e($category->id); ?>)"
                                class="<?php echo e($selected_category == $category->id ? 'bg-gray-500 text-white' : ''); ?> border hover:text-white hover:bg-gray-500 hover:scale-95 border-gray-400 rounded-full px-2 flex space-x-1 text-gray-800 py-1 items-center">
                                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22"
                                    viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                    stroke-linecap="round" stroke-linejoin="round"
                                    class="icon icon-tabler icons-tabler-outline icon-tabler-package">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                    <path d="M12 3l8 4.5l0 9l-8 4.5l-8 -4.5l0 -9l8 -4.5" />
                                    <path d="M12 12l8 -4.5" />
                                    <path d="M12 12l0 9" />
                                    <path d="M12 12l-8 -4.5" />
                                    <path d="M16 5.25l-8 4.5" />
                                </svg>
                                <span class="text-sm font-medium"><?php echo e($category->name); ?></span>
                            </button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                    </div>
                </div>

                <div class="mt-10 grid grid-cols-5 gap-5 " x-auto-animate.linear>
                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div wire:click="getProduct(<?php echo e($product->id); ?>)"
                            class="bg-white cursor-pointer relative overflow-hidden hover:shadow-2xl hover:shadow-green-700  p-2 rounded-2xl">
                            <div class="absolute -right-2 -bottom-10">
                                <svg class="w-40 h-40 opacity-40 text-gray-200" xmlns="http://www.w3.org/2000/svg"
                                    viewBox="0 0 512 512" fill="currentColor">
                                    <path
                                        d="M384,352H184.36l-41,35-41-35H16v24c0,30.59,21.13,55.51,47.26,56,2.43,15.12,8.31,28.78,17.16,39.47C93.51,487.28,112.54,496,134,496H266c21.46,0,40.49-8.72,53.58-24.55,8.85-10.69,14.73-24.35,17.16-39.47,13.88-.25,26.35-7.4,35-18.63A61.26,61.26,0,0,0,384,376Z">
                                    </path>
                                    <path
                                        d="M105,320h0l38.33,28.19L182,320H384v-8a40.07,40.07,0,0,0-32-39.2c-.82-29.69-13-54.54-35.51-72C295.67,184.56,267.85,176,236,176H164c-68.22,0-114.43,38.77-116,96.8A40.07,40.07,0,0,0,16,312v8h89Z">
                                    </path>
                                    <path
                                        d="M463.08,96H388.49l8.92-35.66L442,45,432,16,370,36,355.51,96H208v32h18.75l1.86,16H236c39,0,73.66,10.9,100.12,31.52A121.9,121.9,0,0,1,371,218.07a124.16,124.16,0,0,1,10.73,32.65,72,72,0,0,1,27.89,90.9A96,96,0,0,1,416,376c0,22.34-7.6,43.63-21.4,59.95a80,80,0,0,1-31.83,22.95,109.21,109.21,0,0,1-18.53,33c-1.18,1.42-2.39,2.81-3.63,4.15H416c16,0,23-8,25-23l36.4-345H496V96Z">
                                    </path>
                                </svg>
                            </div>
                            <img src="<?php echo e(Storage::url($product->image_path)); ?>"
                                class="h-28 w-full object-cover rounded-xl relative" alt="">
                            <div class="mt-2 px-2 relative">
                                <h1 class="text-gray-700 font-semibold uppercase"><?php echo e($product->name); ?></h1>
                                <h1 class="text-sm font-medium text-gray-500">
                                    &#8369;<?php echo e(number_format($product->price, 2)); ?></h1>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-span-5">
                            <span>No Products Available...</span>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                </div>
            </div>
        </div>
        <div class="fixed top-24 w-[28rem] right-16   rounded-xl   bg-white">
            <div class="p-5 px-6 border-b">
                <h1 class="font-medium text-gray-700">Order's Summary</h1>
                
                <h1 class="text-xs"><?php echo e($transaction_number); ?></h1>
            </div>
            <div class="p-5 px-6 flex flex-col h-full">
                <div class="flex">
                    <span class="text-sm font-semibold">Total Items</span><span
                        class="font-poppins">(<?php echo e(count($product_items)); ?>)</span>
                </div>
                <div class="mt-10 lg:mt-0">
                    <div class="mt-4 rounded-lg border border-gray-200 bg-white shadow-sm">
                        <h3 class="sr-only">Items in your cart</h3>
                        <ul role="list" class="divide-y divide-gray-200 h-80 overflow-y-auto" x-auto-animate.linear>
                            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $product_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li class="flex px-4 py-3 sm:px-6">
                                    <div class="flex-shrink-0">
                                        <img src="<?php echo e(Storage::url($item['image'])); ?>"
                                            class="h-20 w-20 object-cover rounded-md">
                                    </div>

                                    <div class="ml-2 flex flex-1 flex-col">
                                        <div class="flex">
                                            <div class="min-w-0 flex-1">
                                                <h4 class="text-sm">
                                                    <a href="#"
                                                        class="font-semibold text-gray-700 hover:text-gray-800 uppercase"><?php echo e($item['name']); ?></a>
                                                </h4>
                                            </div>

                                            <div class="ml-4 flow-root flex-shrink-0">
                                                <button type="button" wire:click="removeProduct(<?php echo e($key); ?>)"
                                                    class="-m-2.5 flex items-center justify-center bg-white p-2.5 text-red-400 hover:text-red-500">
                                                    <span class="sr-only">Remove</span>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24"
                                                        height="24" viewBox="0 0 24 24" fill="none"
                                                        stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                                        stroke-linejoin="round"
                                                        class="icon icon-tabler icons-tabler-outline icon-tabler-backspace">
                                                        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                                        <path
                                                            d="M20 6a1 1 0 0 1 1 1v10a1 1 0 0 1 -1 1h-11l-5 -5a1.5 1.5 0 0 1 0 -2l5 -5z" />
                                                        <path d="M12 10l4 4m0 -4l-4 4" />
                                                    </svg>
                                                </button>
                                            </div>
                                        </div>

                                        <div class="flex flex-1 items-end justify-between pt-2">
                                            <p class="mt-1 text-sm font-medium text-gray-900">
                                                &#8369;<?php echo e(number_format($item['price'], 2)); ?>

                                            </p>
                                            <div class="ml-4">
                                                <label for="quantity" class="sr-only">Quantity</label>
                                                <span>Qty: <?php echo e($item['quantity']); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="px-4 py-3 sm:px-6 text-center text-gray-500">
                                    <div class="grid place-content-center mt-10 space-y-5">

                                        <svg xmlns="http://www.w3.org/2000/svg" data-name="Layer 1" class="h-40"
                                            viewBox="0 0 647.63626 632.17383"
                                            xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <path
                                                d="M687.3279,276.08691H512.81813a15.01828,15.01828,0,0,0-15,15v387.85l-2,.61005-42.81006,13.11a8.00676,8.00676,0,0,1-9.98974-5.31L315.678,271.39691a8.00313,8.00313,0,0,1,5.31006-9.99l65.97022-20.2,191.25-58.54,65.96972-20.2a7.98927,7.98927,0,0,1,9.99024,5.3l32.5498,106.32Z"
                                                transform="translate(-276.18187 -133.91309)" fill="#f2f2f2" />
                                            <path
                                                d="M725.408,274.08691l-39.23-128.14a16.99368,16.99368,0,0,0-21.23-11.28l-92.75,28.39L380.95827,221.60693l-92.75,28.4a17.0152,17.0152,0,0,0-11.28028,21.23l134.08008,437.93a17.02661,17.02661,0,0,0,16.26026,12.03,16.78926,16.78926,0,0,0,4.96972-.75l63.58008-19.46,2-.62v-2.09l-2,.61-64.16992,19.65a15.01489,15.01489,0,0,1-18.73-9.95l-134.06983-437.94a14.97935,14.97935,0,0,1,9.94971-18.73l92.75-28.4,191.24024-58.54,92.75-28.4a15.15551,15.15551,0,0,1,4.40966-.66,15.01461,15.01461,0,0,1,14.32032,10.61l39.0498,127.56.62012,2h2.08008Z"
                                                transform="translate(-276.18187 -133.91309)" fill="#3f3d56" />
                                            <path
                                                d="M398.86279,261.73389a9.0157,9.0157,0,0,1-8.61133-6.3667l-12.88037-42.07178a8.99884,8.99884,0,0,1,5.9712-11.24023l175.939-53.86377a9.00867,9.00867,0,0,1,11.24072,5.9707l12.88037,42.07227a9.01029,9.01029,0,0,1-5.9707,11.24072L401.49219,261.33887A8.976,8.976,0,0,1,398.86279,261.73389Z"
                                                transform="translate(-276.18187 -133.91309)" fill="#777777" />
                                            <circle cx="190.15351" cy="24.95465" r="20" fill="#777777" />
                                            <circle cx="190.15351" cy="24.95465" r="12.66462" fill="#fff" />
                                            <path
                                                d="M878.81836,716.08691h-338a8.50981,8.50981,0,0,1-8.5-8.5v-405a8.50951,8.50951,0,0,1,8.5-8.5h338a8.50982,8.50982,0,0,1,8.5,8.5v405A8.51013,8.51013,0,0,1,878.81836,716.08691Z"
                                                transform="translate(-276.18187 -133.91309)" fill="#e6e6e6" />
                                            <path
                                                d="M723.31813,274.08691h-210.5a17.02411,17.02411,0,0,0-17,17v407.8l2-.61v-407.19a15.01828,15.01828,0,0,1,15-15H723.93825Zm183.5,0h-394a17.02411,17.02411,0,0,0-17,17v458a17.0241,17.0241,0,0,0,17,17h394a17.0241,17.0241,0,0,0,17-17v-458A17.02411,17.02411,0,0,0,906.81813,274.08691Zm15,475a15.01828,15.01828,0,0,1-15,15h-394a15.01828,15.01828,0,0,1-15-15v-458a15.01828,15.01828,0,0,1,15-15h394a15.01828,15.01828,0,0,1,15,15Z"
                                                transform="translate(-276.18187 -133.91309)" fill="#3f3d56" />
                                            <path
                                                d="M801.81836,318.08691h-184a9.01015,9.01015,0,0,1-9-9v-44a9.01016,9.01016,0,0,1,9-9h184a9.01016,9.01016,0,0,1,9,9v44A9.01015,9.01015,0,0,1,801.81836,318.08691Z"
                                                transform="translate(-276.18187 -133.91309)" fill="#777777" />
                                            <circle cx="433.63626" cy="105.17383" r="20" fill="#777777" />
                                            <circle cx="433.63626" cy="105.17383" r="12.18187" fill="#fff" />
                                        </svg>
                                        <p>No items
                                        <p>
                                    </div>
                                </li>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </ul>

                        <div>

                            <dl class="space-y-2 border-t border-gray-200 px-4 py-6 sm:px-6">
                                <?php if (isset($component)) { $__componentOriginal125559500674abc14ca4c750a63c3764 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal125559500674abc14ca4c750a63c3764 = $attributes; } ?>
<?php $component = WireUi\Components\TextField\Input::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Components\TextField\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'PWD/Senior Discount','wire:model.live' => 'discount','type' => 'number']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal125559500674abc14ca4c750a63c3764)): ?>
<?php $attributes = $__attributesOriginal125559500674abc14ca4c750a63c3764; ?>
<?php unset($__attributesOriginal125559500674abc14ca4c750a63c3764); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal125559500674abc14ca4c750a63c3764)): ?>
<?php $component = $__componentOriginal125559500674abc14ca4c750a63c3764; ?>
<?php unset($__componentOriginal125559500674abc14ca4c750a63c3764); ?>
<?php endif; ?>
                                <div class="flex items-center justify-between mt-5">
                                    <dt class="text-sm">Subtotal</dt>
                                    <dd class="text-sm font-medium text-gray-900">
                                        &#8369;<?php echo e(number_format($subtotal, 2)); ?>

                                    </dd>
                                </div>
                                <div class="flex items-center justify-between">
                                    <dt class="text-sm">Discount</dt>
                                    <dd class="text-sm font-medium text-gray-900">
                                        &#8369;<?php echo e(number_format($discount, 2)); ?>

                                    </dd>
                                </div>
                                <div class="flex items-center justify-between">
                                    <dt class="text-sm">VAT</dt>
                                    <dd class="text-sm font-medium text-gray-900">
                                        &#8369;<?php echo e(number_format($vat, 2)); ?>

                                    </dd>
                                </div>
                                <div class="flex items-center justify-between border-t border-gray-200 pt-6">
                                    <dt class="text-base font-medium">Total</dt>
                                    <dd class="text-base font-medium text-gray-900">
                                        &#8369;<?php echo e(number_format($total, 2)); ?>

                                    </dd>
                                </div>
                            </dl>
                        </div>

                        <div class="border-t border-gray-200 px-2 py-3 sm:px-2">
                            <?php if (isset($component)) { $__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1 = $attributes; } ?>
<?php $component = WireUi\Components\Button\Base::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Components\Button\Base::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'CONFIRM ORDER','wire:click' => 'confirmOrder','spinner' => 'confirmOrder','positive' => true,'class' => 'w-full font-bold','right-icon' => 'check-circle','lg' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1)): ?>
<?php $attributes = $__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1; ?>
<?php unset($__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1)): ?>
<?php $component = $__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1; ?>
<?php unset($__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1); ?>
<?php endif; ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    
    <div>

        <div x-cloak x-show="modalIsOpen" x-transition.opacity.duration.200ms x-trap.inert.noscroll="modalIsOpen"
            class="fixed inset-0 z-30 flex items-end justify-center bg-black/20 p-4 pb-8 backdrop-blur-md sm:items-center lg:p-8"
            role="dialog" aria-modal="true" aria-labelledby="defaultModalTitle">
            <!-- Modal Dialog -->
            <div x-show="modalIsOpen"
                x-transition:enter="transition ease-out duration-200 delay-100 motion-reduce:transition-opacity"
                x-transition:enter-start="opacity-0 scale-y-0" x-transition:enter-end="opacity-100 scale-y-100"
                class="flex max-w-lg flex-col gap-4 overflow-hidden rounded-2xl border border-slate-300 bg-white text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300">
                <!-- Dialog Header -->
                <div
                    class="flex items-center justify-between border-b border-slate-300 bg-slate-100/60 p-4 dark:border-slate-700 dark:bg-slate-900/20">
                    <h3 id="defaultModalTitle" class="font-semibold tracking-wide text-black dark:text-white">
                        Transaction Receipt</h3>
                    <a href="<?php echo e(route('admin.pos')); ?>" aria-label="close modal">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true"
                            stroke="currentColor" fill="none" stroke-width="1.4" class="w-5 h-5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </a>
                </div>
                <!-- Dialog Body -->
                <div class="px-4 py-8 w-96">
                    <div id="printable-div" x-ref="printContainer" class=" print-content ">
                        <div class="text-center">
                            <h1>Garage91</h1>
                            <h1>COMPANYNAME</h1>
                            <h1>VAT Reg TIN:</h1>
                            <h1>Nimble POS</h1>
                        </div>
                        <div class="mt-10">
                            <h1>Official Receipt No.: <?php echo e($transaction_number ?? 's'); ?></h1>
                            <h1>TXN Number:</h1>
                            <h1>Cashier: <?php echo e(auth()->user()->name); ?></h1>
                        </div>
                        <div class="border-4 mt-5 border-gray-700"></div>
                        <div class="mt-5">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $product_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="grid grid-cols-4">
                                    <div class="col-span-2">
                                        <?php echo e($item['name']); ?>

                                    </div>
                                    <div><?php echo e($item['quantity']); ?>x</div>
                                    <div class="text-right">
                                        &#8369;<?php echo e(number_format($item['price'] * $item['quantity'], 2)); ?>

                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="mt-5">
                            <div class="grid grid-cols-2">
                                <div class="font-bold text-right">SUBTOTAL:</div>
                                <div class="text-right">&#8369;<?php echo e(number_format($subtotal, 2)); ?></div>
                            </div>
                        </div>
                        <div class="mt-5">
                            <div class="grid grid-cols-2">

                                <div class="">Vat Amount</div>
                                <div class="text-right">&#8369;<?php echo e(number_format($vat, 2)); ?></div>
                                <div class="">Discount</div>
                                <div class="text-right">&#8369;<?php echo e(number_format($discount, 2)); ?></div>
                                <div class="font-bold">TOTAL</div>
                                <div class="text-right font-bold">&#8369;<?php echo e(number_format($total, 2)); ?></div>
                            </div>

                        </div>
                        <div class="border-4 my-5 border-gray-700"></div>
                        <div class="mt-5">
                            <div class="text-center">
                                <h1>Thank you for shopping with us!</h1>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- Dialog Footer -->
                <div
                    class="flex flex-col-reverse justify-between gap-2 border-t border-slate-300 bg-slate-100/60 p-4 dark:border-slate-700 dark:bg-slate-900/20 sm:flex-row sm:items-center md:justify-end">
                    
                    <button type="button" @click="printOut($refs.printContainer.outerHTML);"
                        class="cursor-pointer whitespace-nowrap rounded-2xl bg-gray-700 px-4 py-2 text-center text-sm font-medium tracking-wide text-slate-100 transition hover:opacity-75 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-700 active:opacity-100 active:outline-offset-0 dark:bg-blue-600 dark:text-slate-100 dark:focus-visible:outline-blue-600">
                        Print Now
                    </button>
                </div>
            </div>
        </div>
    </div>

</div>
<?php /**PATH C:\Users\johnr\Herd\nimblepos\resources\views/livewire/admin/point-of-sale.blade.php ENDPATH**/ ?>