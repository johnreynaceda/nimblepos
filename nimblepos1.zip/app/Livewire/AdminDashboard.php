<?php

namespace App\Livewire;

use App\Models\Transaction;
use Carbon\Carbon;
use Livewire\Component;

class AdminDashboard extends Component
{
  
    public $netsales = [];
    public $lastYearSales = [];

    public $grossSales = [];
    public $lastYearGrossSales = [];

    public function mount(){
         // Initialize arrays for 12 months (zero-indexed)
         $this->netsales = array_fill(0, 12, 0);
         $this->lastYearSales = array_fill(0, 12, 0);
         $this->grossSales = array_fill(0, 12, 0);
         $this->lastYearGrossSales = array_fill(0, 12, 0);
 
         // Get net sales for the current year, grouped by month
         $currentYearSales = Transaction::whereYear('created_at', Carbon::now()->year)
             ->get()
             ->groupBy(function ($date) {
                 return Carbon::parse($date->created_at)->format('n'); // Group by month (1-12)
             });
 
         foreach ($currentYearSales as $month => $transactions) {
             $this->netsales[$month - 1] = $transactions->sum('total_amount'); // Net sales
             $this->grossSales[$month - 1] = $transactions->sum('total_amount'); // Gross sales
         }
 
         // Get net sales for the previous year, grouped by month
         $previousYearSales = Transaction::whereYear('created_at', Carbon::now()->subYear()->year)
             ->get()
             ->groupBy(function ($date) {
                 return Carbon::parse($date->created_at)->format('n'); // Group by month (1-12)
             });
 
         foreach ($previousYearSales as $month => $transactions) {
             $this->lastYearSales[$month - 1] = $transactions->sum('total_amount');
             $this->lastYearGrossSales[$month - 1] = $transactions->sum('total_amount'); // Last year gross sales
         }
    }
   

    public function render()
    {
        return view('livewire.admin-dashboard');
    }
}
