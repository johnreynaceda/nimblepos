<div>
    <?php echo e($this->table); ?>

</div>
<?php /**PATH C:\Users\johnr\Herd\nimblepos\resources\views/livewire/admin/category-list.blade.php ENDPATH**/ ?>