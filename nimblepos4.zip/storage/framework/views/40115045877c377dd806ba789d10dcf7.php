<?php if (isset($component)) { $__componentOriginala467e27a8a64a28aea549eeab6f9a9c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala467e27a8a64a28aea549eeab6f9a9c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="px-4 mx-auto 2xl:max-w-7xl sm:px-6 md:px-8">
        <!-- === Remove and replace with your own content... === -->
        <div class="py-4">
            <h1 class="text-3xl font-bold text-gray-700">Category</h1>

            <div class="mt-10 ">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.category-list', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3648634721-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </div>
        <!-- === End ===  -->
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala467e27a8a64a28aea549eeab6f9a9c7)): ?>
<?php $attributes = $__attributesOriginala467e27a8a64a28aea549eeab6f9a9c7; ?>
<?php unset($__attributesOriginala467e27a8a64a28aea549eeab6f9a9c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala467e27a8a64a28aea549eeab6f9a9c7)): ?>
<?php $component = $__componentOriginala467e27a8a64a28aea549eeab6f9a9c7; ?>
<?php unset($__componentOriginala467e27a8a64a28aea549eeab6f9a9c7); ?>
<?php endif; ?>
<?php /**PATH C:\Users\johnr\Herd\nimblepos\resources\views/admin/category.blade.php ENDPATH**/ ?>