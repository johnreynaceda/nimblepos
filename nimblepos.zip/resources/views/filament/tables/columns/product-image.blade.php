<img src="{{ Storage::url($getRecord()->image_path) }}" class="h-12 w-12 object-cover rounded-xl ml-3" alt="">
