<x-main-layout>
    <div>
        <livewire:admin.point-of-sale />
    </div>
</x-main-layout>
