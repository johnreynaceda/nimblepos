<div x-data="{
    netsales: @entangle('netsales'),
    lastYearSales: @entangle('lastYearSales'),
    grossSales: @entangle('grossSales'),
    lastYearGrossSales: @entangle('lastYearGrossSales'),
    categories: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
    initNetSalesChart() {
        var options = {
            chart: {
                type: 'line'
            },
            series: [{
                    name: 'Net Sales (This Year)',
                    data: this.netsales
                },
                {
                    name: 'Net Sales (Last Year)',
                    data: this.lastYearSales
                }
            ],
            xaxis: {
                categories: this.categories
            }
        };
        var chart = new ApexCharts(document.querySelector('#net-sales-chart'), options);
        chart.render();
    },
    initGrossSalesChart() {
        var options = {
            chart: {
                type: 'line'
            },
            series: [{
                    name: 'Gross Sales (This Year)',
                    data: this.grossSales
                },
                {
                    name: 'Gross Sales (Last Year)',
                    data: this.lastYearGrossSales
                }
            ],
            xaxis: {
                categories: this.categories
            }
        };
        var chart = new ApexCharts(document.querySelector('#gross-sales-chart'), options);
        chart.render();
    }
}" x-init="initNetSalesChart();
initGrossSalesChart();">
    <div class="mt-10 grid grid-cols-2 gap-5">
        <!-- Net Sales Chart -->
        <div class="bg-white p-5 rounded-xl">
            <h2 class="text-lg font-bold">Net Sales Chart</h2>
            <div id="net-sales-chart"></div>
        </div>

        <!-- Gross Sales Chart inside a black div -->
        <div class="bg-white p-5 rounded-xl">
            <h2 class="text-lg font-bold">Gross Sales Chart</h2>
            <div id="gross-sales-chart"></div>
        </div>
    </div>
</div>
