<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/@marcreichel/alpine-auto-animate@latest/dist/alpine-auto-animate.min.js"
        defer></script>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

    <?php echo WireUi::directives()->scripts(attributes: []); ?>

    <style>
        [x-cloak] {
            display: none !important;
        }
    </style>

    <style>
        /* width */
        ::-webkit-scrollbar {
            width: 6px;
        }

        /* Track */
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }

        /* Handle */
        ::-webkit-scrollbar-thumb {
            background: #888;
        }

        /* Handle on hover */
        ::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
    </style>

    <?php echo \Filament\Support\Facades\FilamentAsset::renderStyles() ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>

<body class="font-sans antialiased">
    <?php if (isset($component)) { $__componentOriginaladf7d5283c6c06cb103ae62523e6a412 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaladf7d5283c6c06cb103ae62523e6a412 = $attributes; } ?>
<?php $component = WireUi\Components\Dialog\Index::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dialog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Components\Dialog\Index::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['z-index' => 'z-50','blur' => 'md','align' => 'center']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaladf7d5283c6c06cb103ae62523e6a412)): ?>
<?php $attributes = $__attributesOriginaladf7d5283c6c06cb103ae62523e6a412; ?>
<?php unset($__attributesOriginaladf7d5283c6c06cb103ae62523e6a412); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaladf7d5283c6c06cb103ae62523e6a412)): ?>
<?php $component = $__componentOriginaladf7d5283c6c06cb103ae62523e6a412; ?>
<?php unset($__componentOriginaladf7d5283c6c06cb103ae62523e6a412); ?>
<?php endif; ?>
    <div class="flex h-screen overflow-hidden bg-gradient-to-tl from-gray-300 to-gray-100">
        <nav class="flex flex-col justify-between w-20 bg-white border-r">
            <div class="mt-5 mb-10">
                <a href="#">
                    <img src="<?php echo e(asset('images/logo.jpg')); ?>" class="object-cover w-10 h-10 mx-auto mb-3 rounded-xl">
                </a>
                <div class="mt-10">
                    <?php if (isset($component)) { $__componentOriginal7b24d5ecfa145fae5aa3e54cf888e508 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b24d5ecfa145fae5aa3e54cf888e508 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.adminside','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('adminside'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b24d5ecfa145fae5aa3e54cf888e508)): ?>
<?php $attributes = $__attributesOriginal7b24d5ecfa145fae5aa3e54cf888e508; ?>
<?php unset($__attributesOriginal7b24d5ecfa145fae5aa3e54cf888e508); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b24d5ecfa145fae5aa3e54cf888e508)): ?>
<?php $component = $__componentOriginal7b24d5ecfa145fae5aa3e54cf888e508; ?>
<?php unset($__componentOriginal7b24d5ecfa145fae5aa3e54cf888e508); ?>
<?php endif; ?>
                </div>
            </div>
            <div class="mb-4 ">
                <ul class="space-y-3">
                    
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('logout', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2162674461-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </ul>

            </div>
        </nav>
        <div class="flex flex-col flex-1 w-0 overflow-hidden">
            <main class="relative flex-1 overflow-y-auto focus:outline-none">
                <div class="bg-white py-3 sticky top-0 z-10 flex items-center justify-between px-10">
                    <div class="">
                        <span class="font-black text-xl font-poppins text-gray-700">Nimble POS</span>
                        <span class="text-xs">2024</span>
                    </div>
                    <div class="flex space-x-3 items-center border py-1 px-4 rounded-xl">
                        <div class="border rounded-full overflow-hidden"><img src="<?php echo e(asset('images/sample.png')); ?>"
                                class="h-12 w-12 object-cover" alt="">
                        </div>
                        <div class="text-gray-700">
                            <h1 class="uppercase font-bold  font-poppins underline">
                                <?php echo e(auth()->user()->name); ?></h1>
                            <h1 class="leading-3 text-sm "><?php echo e(ucfirst(auth()->user()->user_type)); ?></h1>

                        </div>
                    </div>
                </div>
                <div class="py-6">
                    <?php echo e($slot); ?>

                </div>
            </main>
        </div>
    </div>
    <?php echo \Filament\Support\Facades\FilamentAsset::renderScripts() ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</body>

</html>
<?php /**PATH C:\Users\johnr\Herd\nimblepos\resources\views/components/main-layout.blade.php ENDPATH**/ ?>