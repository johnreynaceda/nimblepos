<div>
    <?php echo e($this->table); ?>

</div>
<?php /**PATH C:\Users\johnr\Herd\nimblepos\resources\views/livewire/admin/product-list.blade.php ENDPATH**/ ?>